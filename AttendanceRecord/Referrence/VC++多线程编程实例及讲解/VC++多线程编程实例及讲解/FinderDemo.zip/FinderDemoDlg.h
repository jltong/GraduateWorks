// FinderDemoDlg.h : header file
//

#if !defined(AFX_FINDERDEMODLG_H__CABCFE46_C992_11D6_A1A8_00902758778B__INCLUDED_)
#define AFX_FINDERDEMODLG_H__CABCFE46_C992_11D6_A1A8_00902758778B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "RapidFinder.h"

/////////////////////////////////////////////////////////////////////////////
// CFinderDemoDlg dialog

class CFinderDemoDlg : public CDialog
{
// Construction
public:
	CFinderDemoDlg(CWnd* pParent = NULL);	// standard constructor
    
	CRapidFinder finder;
	int count;

	// Dialog Data
	//{{AFX_DATA(CFinderDemoDlg)
	enum { IDD = IDD_FINDERDEMO_DIALOG };
	CSpinButtonCtrl	m_spinpriority;
	CSpinButtonCtrl	m_spincount;
	CListCtrl	m_ListCtrl;
	CButton	m_stop;
	CButton	m_pause;
	CButton	m_start;
	CString	m_ActiveCount;
	CString	m_folder;
	CString	m_count;
	CString	m_findfolder;
	CString	m_text;
	CString	m_filename;
	long	m_threadcount;
	int		m_priority;
	//}}AFX_DATA
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFinderDemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
    CString GetAllDriverList();
	CImageList m_imglist;
	void UIControl(BOOL bOp);
	void OnOK();

	// Generated message map functions
	//{{AFX_MSG(CFinderDemoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnStop();
	afx_msg void OnStart();
	afx_msg void OnPause();
	afx_msg void OnBrowse();
	afx_msg void OnChangePriority();
	afx_msg void OnChangeThreadNo();
	//}}AFX_MSG
	afx_msg LRESULT OnFindExit(WPARAM wparam,LPARAM lparam);
	afx_msg LRESULT OnFindPause(WPARAM wparam,LPARAM lparam);
	afx_msg LRESULT OnFindItem(WPARAM wparam,LPARAM lparam);
	afx_msg LRESULT OnFindThreadCount(WPARAM wparam,LPARAM lparam);
	afx_msg LRESULT OnFindingFolder(WPARAM wparam,LPARAM lparam);

	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FINDERDEMODLG_H__CABCFE46_C992_11D6_A1A8_00902758778B__INCLUDED_)
