// FinderDemoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "FinderDemo.h"
#include "FinderDemoDlg.h"
#include "RapidFinder.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP


END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFinderDemoDlg dialog

CFinderDemoDlg::CFinderDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFinderDemoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFinderDemoDlg)
	m_ActiveCount = _T("0");
	m_folder = _T("");//C:\\;D:\\;E:\\;F:\\");
	m_count = _T("0");
	m_findfolder = _T("");
	m_text = _T("");
	m_filename = _T("");
	m_threadcount = 10;
	m_priority = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32

	m_folder=GetAllDriverList();
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CFinderDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFinderDemoDlg)
	DDX_Control(pDX, IDC_SPIN_PRIORITY, m_spinpriority);
	DDX_Control(pDX, IDC_SPIN_THREAD_NO, m_spincount);
	DDX_Control(pDX, IDC_LIST, m_ListCtrl);
	DDX_Control(pDX, IDC_STOP, m_stop);
	DDX_Control(pDX, IDC_PAUSE, m_pause);
	DDX_Control(pDX, IDC_START, m_start);
	DDX_Text(pDX, IDC_ACTIVE_THREAD, m_ActiveCount);
	DDX_Text(pDX, IDC_FOLDER, m_folder);
	DDX_Text(pDX, IDC_COUNT, m_count);
	DDX_Text(pDX, IDC_FINDING_FOLDER, m_findfolder);
	DDX_Text(pDX, IDC_INCLUDE_TEXT, m_text);
	DDX_Text(pDX, IDC_FILENAME, m_filename);
	DDX_Text(pDX, IDC_THREAD_NO, m_threadcount);
	DDX_Text(pDX, IDC_PRIORITY, m_priority);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CFinderDemoDlg, CDialog)
	//{{AFX_MSG_MAP(CFinderDemoDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_STOP, OnStop)
	ON_BN_CLICKED(IDC_START, OnStart)
	ON_BN_CLICKED(IDC_PAUSE, OnPause)
	ON_BN_CLICKED(IDC_BROWSE, OnBrowse)
	ON_EN_CHANGE(IDC_PRIORITY, OnChangePriority)
	ON_EN_CHANGE(IDC_THREAD_NO, OnChangeThreadNo)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_THREADEXIT,  OnFindExit)
	ON_MESSAGE(WM_THREADCOUNT, OnFindThreadCount)
	ON_MESSAGE(WM_FINDERITEM , OnFindItem)
	ON_MESSAGE(WM_THREADPAUSE, OnFindPause)
	ON_MESSAGE(WM_FINDERFOLDER, OnFindingFolder)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFinderDemoDlg message handlers

BOOL CFinderDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	m_ListCtrl.SetExtendedStyle(LVS_EX_FULLROWSELECT|LVS_EX_TRACKSELECT|LVS_EX_FLATSB|LVS_EX_UNDERLINEHOT|LVS_EX_GRIDLINES);
    m_ListCtrl.InsertColumn(0,_T("�ļ���"),LVCFMT_IMAGE|LVCFMT_LEFT,80,80);
	m_ListCtrl.InsertColumn(1,_T("·��"),LVCFMT_LEFT,180);
	m_ListCtrl.InsertColumn(2,_T("��С"),LVCFMT_LEFT,80);
	m_ListCtrl.InsertColumn(3,_T("����"),LVCFMT_LEFT,80);
	m_ListCtrl.SetHoverTime(500);
    
    m_spinpriority.SetRange(-2,2);
	m_spincount.SetRange(1,99);
    m_spinpriority.SetPos(0);
	m_spincount.SetPos(30);
   
	finder.ThreadSet(30);
	m_ListCtrl.SetRedraw();

	UIControl(false);
	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CFinderDemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CFinderDemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CFinderDemoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

LRESULT CFinderDemoDlg::OnFindExit(WPARAM wparam,LPARAM lparam)
{
   
   m_pause.SetWindowText("��ͣ");
   UIControl(false);
   if(wparam==1)AfxMessageBox("ֹͣ����!");
   else AfxMessageBox("���ҽ���!"); 
   m_ListCtrl.RedrawItems(0,count-1);
   return 0;
}
LRESULT CFinderDemoDlg::OnFindPause(WPARAM wparam,LPARAM lparam)
{
   AfxMessageBox("�û���ͣ!");
   return 0;
}
BOOL PeekAndPump()
{
	static MSG msg;
	while(::PeekMessage(&msg,NULL,0,0,PM_NOREMOVE))
	{
		if(!AfxGetApp()->PumpMessage())
		{
			::PostQuitMessage(0);
	     	return false;
		}
	}
	return true ;
}
LRESULT CFinderDemoDlg::OnFindItem(WPARAM wparam,LPARAM lparam)
{
	m_count.Format("%d",++count);
	UpdateData(false);
	CString pathname=*((CString *)wparam);

	CFileStatus Status;
	CFile::GetStatus(pathname,Status);
    CString Unit="Byte";
	float flen=(float)Status.m_size;
	if(flen>1024)
	{   
		flen/=1024;
		if(flen<1024){Unit="KB";}
		else{flen/=1024;Unit="MB";}
	}
	CString Size;
	Size.Format("%1.2f",flen);
    
	int pos=pathname.ReverseFind('\\');
	
	SHFILEINFO sfi;
	if (::SHGetFileInfo (pathname, FILE_ATTRIBUTE_NORMAL, &sfi, sizeof(SHFILEINFO),SHGFI_USEFILEATTRIBUTES | SHGFI_DISPLAYNAME | SHGFI_TYPENAME |SHGFI_ICON|SHGFI_SMALLICON ))
	{	
		m_imglist.Add(sfi.hIcon);
		m_ListCtrl.InsertItem(count-1,sfi.szDisplayName,count-1);

     	m_ListCtrl.SetItemText(count-1,1,pathname.Mid(0,pos));
    	m_ListCtrl.SetItemText(count-1,2,(Size+Unit));
		m_ListCtrl.SetItemText(count-1,3,sfi.szTypeName);
	}
	m_ListCtrl.Update(count-1);
    PeekAndPump();
    return 0;
}


LRESULT CFinderDemoDlg::OnFindThreadCount(WPARAM wparam,LPARAM lparam)
{
	m_ActiveCount.Format("%ld",LONG(wparam));
	UpdateData(FALSE);
	return 0;
}
LRESULT CFinderDemoDlg::OnFindingFolder(WPARAM wparam,LPARAM lparam)
{
	m_findfolder=*((CString *)wparam);
	UpdateData(false);
	return 0;
}

void CFinderDemoDlg::OnStop() 
{
	// TODO: Add your control notification handler code here
	finder.StopFinder();
}

void CFinderDemoDlg::OnStart() 
{
// TODO: Add your control notification handler code here
//	::SendMessage(GetSafeHwnd(),WM_THREADCOUNT,(WPARAM)100,NULL);
   
   UpdateData(true);
   m_count=_T("0");
   m_ActiveCount=_T("0");
   count=0;
   m_imglist.DeleteImageList();
   m_imglist.Create(16, 16, ILC_MASK | ILC_COLORDDB, 1, 100);
   m_ListCtrl.SetImageList(&m_imglist, LVSIL_SMALL);

   m_ListCtrl.DeleteAllItems();
   UpdateData(false);
   
   finder.FinderSet(GetSafeHwnd(),m_filename,m_folder);
   finder.FindWithText(m_text,m_text.GetLength());
 
   finder.StartFinder();
   UIControl(true);
}
void CFinderDemoDlg::OnPause() 
{
	// TODO: Add your control notification handler code here
   
   static BOOL ispause=true;
   if(ispause)
   {
       m_pause.SetWindowText("����");
	   finder.PauseFinder();
	   ispause=false;
   }
   else 
   {
	   m_pause.SetWindowText("��ͣ");
	   finder.ResumeFinder();
	   ispause=true;
   }
}

void CFinderDemoDlg::OnBrowse() 
{
	// TODO: Add your control notification handler code here
	BROWSEINFO bi;
	char dispname[MAX_PATH],path[MAX_PATH];
	ITEMIDLIST *pidl;
	//
	bi.hwndOwner=m_hWnd;
	bi.pidlRoot=0;
	bi.pszDisplayName=dispname;
	bi.lpszTitle="��ѡ�����Ŀ¼��";
	bi.ulFlags=BIF_RETURNONLYFSDIRS|BIF_EDITBOX|BIF_DONTGOBELOWDOMAIN ;
	bi.lpfn=0;
	bi.lParam=0;
	bi.iImage=0;
	if(pidl=SHBrowseForFolder(&bi))
	{
		SHGetPathFromIDList(pidl,path);
        m_folder=CString(path);
		if(m_folder.IsEmpty())m_folder=GetAllDriverList();
		UpdateData(false);
	}	
}
CString CFinderDemoDlg::GetAllDriverList()
{
	CString  tmp=_T("A:\\"),Dir;
	for(int i=1;i<=25;i++)
	{   
		Dir=CString('A'+i)+_T(":\\");
		if(GetDriveType(Dir.GetBuffer(0))==DRIVE_NO_ROOT_DIR)continue;
        tmp+=";"+Dir;
	}
	return tmp;
}
void CFinderDemoDlg::UIControl(BOOL bOp)//start with true;
{
   m_start.EnableWindow(!bOp); 
   m_stop.EnableWindow(bOp);   
   m_pause.EnableWindow(bOp);
   GetDlgItem(IDC_THREAD_NO)->EnableWindow(!bOp);
   GetDlgItem(IDC_SPIN_THREAD_NO)->EnableWindow(!bOp);   
   GetDlgItem(IDC_PRIORITY)->EnableWindow(!bOp);         
   GetDlgItem(IDC_SPIN_PRIORITY)->EnableWindow(!bOp);            
}      

void CFinderDemoDlg::OnChangePriority() 
{
	int pri=GetDlgItemInt(IDC_PRIORITY);
	if(pri<-2||pri>2){pri=0;SetDlgItemInt(IDC_PRIORITY,pri);}
	finder.ThreadSet(finder.GetThreadCount(),pri);	
}
void CFinderDemoDlg::OnChangeThreadNo() 
{

	int count=GetDlgItemInt(IDC_THREAD_NO);
	if(count<1||count>99){count=10;SetDlgItemInt(IDC_THREAD_NO,count);}
	finder.ThreadSet(count,finder.GetThreadPrioriy());		
}
void CFinderDemoDlg::OnOK()
{
	return; 
}
